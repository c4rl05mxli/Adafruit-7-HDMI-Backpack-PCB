                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1597977
Adafruit 7" HDMI Backpack Feet by flimshaw is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Here are some very simple feed to hold up your [Adafruit HDMI Backpack](https://www.adafruit.com/products/2407?gclid=CjwKEAjwya-6BRDR3p6FuY2-u3MSJAD1paxTQvlRYYH_iBV7DEMgU5rDmf05UviFp8i72bA1ggJX8RoC2rHw_wcB).  The display stands up at a 20° angle, no mounting hardware is required.  The tabs are a pretty snug fit, so insert the tabs cautiously and don't just hulk out and snap them off.

EDIT: Added adafruit-lcd-stand.004.obj, which has more of a tilt to the screen.  Better for standard sitting-at-a-desk style viewing.

# Print Settings

Printer: Powerspec Replicator Clone
Rafts: No
Supports: No
Resolution: .2mm
Infill: whatevs

# How I Designed This

## Blender

Original .blend file attached for your remixing pleasure.